function populateMainCategories() {
    const container = document.getElementById("main-category-container");
    categories.forEach((category) => {
      const hr = document.createElement("hr"); // Place line before title
      container.appendChild(hr);

      const categoryTitle = document.createElement("div");
      categoryTitle.classList.add("category-title");
      categoryTitle.textContent = category.name;
      container.appendChild(categoryTitle);

      // Create a row for the subcategories
      const subcategoriesRow = document.createElement("div");
      subcategoriesRow.classList.add("main-categories");
      category.subcategories.forEach((subcategory) => {
        const subcategoryElement = document.createElement("div");
        subcategoryElement.classList.add("main-category");
        subcategoryElement.innerHTML = `
                    <img src="${subcategory.img}" alt="${subcategory.name}">
                    <p>${subcategory.name}</p>
                `;
        subcategoriesRow.appendChild(subcategoryElement);
      });
      container.appendChild(subcategoriesRow);
    });
  }
  const searchInput = document.getElementById('searchInput');
    const searchSuggestions = document.getElementById('searchSuggestions');

    // Fetch suggestions immediately when the input is focused
    searchInput.addEventListener('focus', function() {
        fetchSuggestions(''); // Pass an empty string to show all suggestions
    });

    searchInput.addEventListener('input', function() {
        const query = searchInput.value.trim();
        fetchSuggestions(query);
    });

    searchInput.addEventListener('blur', function() {
        hideSuggestions();
    });

    function fetchSuggestions(query) {
        const suggestions = [
            { label: 'plumbing', value: 'service-1' },
            { label: 'tutoring', value: 'service-2' },
            { label: 'facial', value: 'service-3' },
            { label: 'hair-cut', value: 'service-4' },
            { label: 'cooking', value: 'service-5' }
        ];

        const filteredSuggestions = suggestions.filter(suggestion => {
            return suggestion.label.toLowerCase().includes(query.toLowerCase());
        });

        populateSuggestions(filteredSuggestions);
    }

    function populateSuggestions(suggestions) {
        searchSuggestions.innerHTML = '';
        suggestions.forEach(suggestion => {
            const li = document.createElement('li');
            li.textContent = suggestion.label;
            li.dataset.value = suggestion.value;
            searchSuggestions.appendChild(li);
        });
        showSuggestions();
    }

    function showSuggestions() {
        searchSuggestions.classList.remove('hidden');
        searchSuggestions.style.display = 'block';
    }

    function hideSuggestions() {
        searchSuggestions.classList.add('hidden');
        searchSuggestions.style.display = 'none';
    }

    searchSuggestions.addEventListener('click', function(event) {
        if (event.target.tagName === 'LI') {
            const selectedValue = event.target.dataset.value;
            searchInput.value = event.target.textContent;
            hideSuggestions();
        }
    });
    